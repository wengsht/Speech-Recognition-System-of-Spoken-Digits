//
//  srs.h
//  SpeechRecongnitionSystem
//
//  Created by Admin on 9/8/14.
//  Copyright (c) 2014 Admin. All rights reserved.
//

#ifndef SpeechRecongnitionSystem_srs_h
#define SpeechRecongnitionSystem_srs_h
#include "test.h"


#include "AutoCapture.h"
#include "Capture.h"

#include "RawData.h"

#include "EPAnalysis.h"
#include "AEPAnalysis.h"
#include "BEPAnalysis.h"
#include "DAEPAnalysis.h"

#include "stringtool.h"
//#include "StringMatch.h"

#endif
