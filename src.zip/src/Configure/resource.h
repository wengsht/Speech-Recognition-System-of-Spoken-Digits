//
//  common.h
//  SpeechRecongnitionSystem
//
//  Created by Admin on 8/27/14.
//  Copyright (c) 2014 Admin. All rights reserved.
//

#ifndef SpeechRecongnitionSystem_common_h
#define SpeechRecongnitionSystem_common_h
#include "tool.h"
#include "configure.h"
//#include "srs.h"

#endif
