#ifndef __PRO3__EDITDISTANCE__CONF__
#define __PRO3__EDITDISTANCE__CONF__
class Conf{
public:
    static int threshold;
    static int beam;
	static int info;
    static int debug;
};

#endif
